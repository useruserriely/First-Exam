public class Exam2 {
    public static void main(String[] args) {
            // 높이 : 3

            /*

             *
             ***
             *****

             */

            // 높이 : 5

            // 출력

            /*

             *
             ***
             *****
             *******
             *********

             */

            // 높이 : 7

            // 출력

            /*

             *
             ***
             *****
             *******
             *********
             ***********
             *************

             */

            int y1 = 3;

            for (int i = 1; i <= y1; i++) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }

            int y2 = 5;

            for (int i = 1; i <= y2; i++) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }

            int y3 = 7;

            for (int i = 1; i <= y3; i++) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        }
    }


